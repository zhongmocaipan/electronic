#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int8_t Serial2_TxPacket[9];
int8_t Serial2_1_TxPacket[19];



void usart2_Init(u32 bound)
{
	//GPIO�˿�����
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);                           //ʹ��USART2ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,  ENABLE);     //ʹ��GPIOAʱ�ӣ��˿ڸ���ʱ��
	
	//USART2_TX   GPIOA.2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;                        //PA.2
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;                //����ʡ�Դ�����һ��ɾ�����Ͳ�������
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	                 //�����������
    GPIO_Init(GPIOA, &GPIO_InitStructure);                           //��ʼ��GPIOA.2
   
	
  //USART2_RX	  GPIOA.3��ʼ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;                        //PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;            //��������
    GPIO_Init(GPIOA, &GPIO_InitStructure);                           //��ʼ��GPIOA.3  
	
	
		//USART ��ʼ������
	USART_InitStructure.USART_BaudRate = bound;                                        //���ڲ�����
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;                        //�ֳ�Ϊ8λ���ݸ�ʽ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;                             //һ��ֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;                                //����żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;    //��Ӳ������������
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	                   //�շ�ģʽ
    USART_Init(USART2, &USART_InitStructure);                                          //��ʼ������2	
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);                   //�������ڽ����ж�


	
	//Usart2 NVIC ����
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2 ;          //��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;		            //�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			              //IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	                                  //����ָ���Ĳ�����ʼ��VIC�Ĵ���
	
	USART_Cmd(USART2, ENABLE);

}




void Serial2_SendByte(uint8_t Byte)
{
	USART_SendData(USART2,Byte);
	while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
}

void Serial2_SendArray(int8_t *Array, uint16_t Length)
{
	uint16_t i;
	for(i=0;i<Length;i++)
	{
		Serial2_SendByte(Array[i]);
	}
}
void MachineControl(int8_t id , int16_t angle, int16_t time)
{
	int16_t pos;
	int8_t value_H;
	int8_t value_L;
	int8_t time_H;
	int8_t time_L;
	if(id==2||id==3||id==4)
	{
		angle=1800-angle;
		pos=(int16_t)((((int32_t)(3100-900)*(int32_t)(angle - 0))/(int32_t)180+(int32_t)9000)/(int32_t)10);
		
		value_H = (pos >> 8) & 0xFF;
		value_L = pos & 0xFF;
		time_H = (time >> 8) & 0xFF;
		time_L = time & 0xFF;
		
		Serial2_TxPacket[0]=0xff;
		Serial2_TxPacket[1]=0xfc;
		Serial2_TxPacket[2]=0x07;
		Serial2_TxPacket[3]=0x10+id;
		Serial2_TxPacket[4]=value_H;
		Serial2_TxPacket[5]=value_L;
		Serial2_TxPacket[6]=time_H;
		Serial2_TxPacket[7]=time_L;
		Serial2_TxPacket[8]=(0x07+0x10+id+value_H+value_L+time_H+time_L) & 0xff;
		Delay_ms(20);
		Serial2_SendArray(Serial2_TxPacket,9);
	}
	
	if(id==5)
	{
		pos=(int16_t)((((int32_t)(3700-380)*(int32_t)(angle - 0))/(int32_t)270+(int32_t)3800)/(int32_t)10);
		
		value_H = (pos >> 8) & 0xFF;
		value_L = pos & 0xFF;
		time_H = (time >> 8) & 0xFF;
		time_L = time & 0xFF;
		
		Serial2_TxPacket[0]=0xff;
		Serial2_TxPacket[1]=0xfc;
		Serial2_TxPacket[2]=0x07;
		Serial2_TxPacket[3]=0x10+id;
		Serial2_TxPacket[4]=value_H;
		Serial2_TxPacket[5]=value_L;
		Serial2_TxPacket[6]=time_H;
		Serial2_TxPacket[7]=time_L;
		Serial2_TxPacket[8]=(0x07+0x10+id+value_H+value_L+time_H+time_L) & 0xff;
		Delay_ms(20);
		Serial2_SendArray(Serial2_TxPacket,9);
	}
	
	else
	{
		pos=(int16_t)((((int32_t)(3100-900)*(int32_t)(angle - 0))/(int32_t)180+(int32_t)9000)/(int32_t)10);
		
		value_H = (pos >> 8) & 0xFF;
		value_L = pos & 0xFF;
		time_H = (time >> 8) & 0xFF;
		time_L = time & 0xFF;
		
		Serial2_TxPacket[0]=0xff;
		Serial2_TxPacket[1]=0xfc;
		Serial2_TxPacket[2]=0x07;
		Serial2_TxPacket[3]=0x10+id;
		Serial2_TxPacket[4]=value_H;
		Serial2_TxPacket[5]=value_L;
		Serial2_TxPacket[6]=time_H;
		Serial2_TxPacket[7]=time_L;
		Serial2_TxPacket[8]=(0x07+(0x10+id)+value_H+value_L+time_H+time_L) & 0xff;
		Delay_ms(20);
		Serial2_SendArray(Serial2_TxPacket,9);
	}
}


void MultiMachineControl(int16_t s1 , int16_t s2, int16_t s3,int16_t s4,int16_t s5,int16_t s6,int16_t time)
{
	if (s1 > 1800 || s2 > 1800 || s3 > 1800 || s4 > 1800 || s5 > 2700 || s6 > 1800)
	{
		OLED_ShowString(0,0,"The limit is exceeded, re-enter!",OLED_8X16);
		OLED_Update();
		return;
	}
	int16_t pos;
	int8_t value1_H;
	int8_t value1_L;
	int8_t value2_H;
	int8_t value2_L;
	int8_t value3_H;
	int8_t value3_L;
	int8_t value4_H;
	int8_t value4_L;
	int8_t value5_H;
	int8_t value5_L;
	int8_t value6_H;
	int8_t value6_L;
	int8_t time_H;
	int8_t time_L;
	pos = (int16_t)(((int32_t)(3100 - 900) * (int32_t)(s1 - 0) / (int32_t)(180 - 0) + (int32_t)9000)/(int32_t)10);
	value1_H = (pos >> 8) & 0xFF;
	value1_L = pos & 0xFF;
	
	s2 = 1800 - s2;
	pos = (int16_t)(((int32_t)(3100 - 900) * (int32_t)(s2 - 0) / (int32_t)(180 - 0) + (int32_t)9000)/(int32_t)10);
	value2_H = (pos >> 8) & 0xFF;
	value2_L = pos & 0xFF;
	
	s3 = 1800 - s3;
	pos = (int16_t)(((int32_t)(3100 - 900) * (int32_t)(s3 - 0) / (int32_t)(180 - 0) + (int32_t)9000)/(int32_t)10);
	value3_H = (pos >> 8) & 0xFF;
	value3_L = pos & 0xFF;
	
	s4 = 1800 - s4;
	pos = (int16_t)(((int32_t)(3100 - 900) * (int32_t)(s4 - 0) / (int32_t)(180 - 0) + (int32_t)9000)/(int32_t)10);
	value4_H = (pos >> 8) & 0xFF;
	value4_L = pos & 0xFF;
	
	pos = (int16_t)(((int32_t)(3700 - 380) * (int32_t)(s5 - 0) / (int32_t)(270 - 0) + (int32_t)3800)/(int32_t)10);
	value5_H = (pos >> 8) & 0xFF;
	value5_L = pos & 0xFF;
	
	pos = (int16_t)(((int32_t)(3100 - 900) * (int32_t)(s6 - 0) / (int32_t)(180 - 0) + (int32_t)9000)/(int32_t)10);
	value6_H = (pos >> 8) & 0xFF;
	value6_L = pos & 0xFF;
	
	time_H = (time >> 8) & 0xFF;
	time_L = time & 0xFF;
	
	Serial2_1_TxPacket[0]=0xff;
	Serial2_1_TxPacket[1]=0xfc;
	Serial2_1_TxPacket[2]=0x11;
	Serial2_1_TxPacket[3]=0x1d;
	Serial2_1_TxPacket[4]=value1_H;
	Serial2_1_TxPacket[5]=value1_L;
	Serial2_1_TxPacket[6]=value2_H;
	Serial2_1_TxPacket[7]=value2_L;
	Serial2_1_TxPacket[8]=value3_H;
	Serial2_1_TxPacket[9]=value3_L;
	Serial2_1_TxPacket[10]=value4_H;
	Serial2_1_TxPacket[11]=value4_L;
	Serial2_1_TxPacket[12]=value5_H;
	Serial2_1_TxPacket[13]=value5_L;
	Serial2_1_TxPacket[14]=value6_H;
	Serial2_1_TxPacket[15]=value6_L;
	Serial2_1_TxPacket[16]=time_H;
	Serial2_1_TxPacket[17]=time_L;
	Serial2_1_TxPacket[18]=(0x11+0x1d+value1_H+value1_L+value2_H+value2_L+value3_H+value3_L+value4_H+value4_L+value5_H+value5_L+value6_H+value6_L+time_H+time_L) & 0xff;
	Serial2_SendArray(Serial2_1_TxPacket,19);
	
}

void USART2_IRQHandler(void)
{
	if (USART_GetITStatus(USART2,USART_IT_RXNE)==SET)
	{
		uint8_t RxData =USART_ReceiveData(USART2);
		
		USART_ClearITPendingBit(USART3,USART_IT_RXNE);
	}
	
}

