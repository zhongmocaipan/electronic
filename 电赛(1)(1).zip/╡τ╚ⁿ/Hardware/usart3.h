#ifndef __USART3_H
#define	__USART3

extern uint8_t Serial3_RxPacket[9];
extern uint8_t Serial3_RxFlag;
extern uint8_t Serial3_RxOK;

void SomeDuojiControl(int8_t id , int16_t angle, int16_t time);
void usart3_Init(u32 bound);
uint8_t Serial3_GetRxFlag(void);

#endif
