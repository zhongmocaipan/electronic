#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include "OLED.h"
extern uint8_t Serial2_xPacket[121];
extern uint8_t jiaodu[11];
extern uint32_t x;//x��
extern uint32_t y;
extern uint32_t z;
extern int32_t want;


uint8_t Serial_RxData;
uint8_t Serial_RxFlag;
uint8_t Serial_OK;
uint8_t Pid1[6];
uint16_t P1;
uint16_t I1;
uint16_t D1;

void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_Instructure;
	GPIO_Instructure.GPIO_Mode= GPIO_Mode_AF_PP;
	GPIO_Instructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_Instructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_Instructure);
	
	GPIO_Instructure.GPIO_Mode= GPIO_Mode_IPU;
	GPIO_Instructure.GPIO_Pin=GPIO_Pin_10;
	GPIO_Instructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_Instructure);
	
	USART_InitTypeDef USART_InitStruture;
	USART_InitStruture.USART_BaudRate=9600;
	USART_InitStruture.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStruture.USART_Mode=USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStruture.USART_Parity=USART_Parity_No;
	USART_InitStruture.USART_StopBits=USART_StopBits_1;
	USART_InitStruture.USART_WordLength=USART_WordLength_8b;
	USART_Init(USART1,&USART_InitStruture);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_Init_Structure;
	NVIC_Init_Structure.NVIC_IRQChannel=USART1_IRQn;
	NVIC_Init_Structure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init_Structure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_Init_Structure.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_Init_Structure);
	
	USART_Cmd(USART1,ENABLE);
	
	
	
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1,Byte);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
}



void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for(i=0;i<Length;i++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial_SendString(char *String)
{
	uint8_t i;
	for(i=0;String[i]!='\0';i++)
	{
		Serial_SendByte(String[i]);
	}
}

void Serial_SendNumber(uint32_t Number,uint8_t Length)
{
	 
}

int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);
	return ch;
}


uint8_t Serial_GetRxData(void)
{
	return Serial_RxData;
}

void USART1_IRQHandler(void)
{
	static uint8_t RxState=0;
	static uint8_t PIDPAG=0;
	if (USART_GetITStatus(USART1,USART_IT_RXNE)==SET)
	{
		Serial_RxData=USART_ReceiveData(USART1);
		
		if(RxState==1)
		{
			Pid1[PIDPAG]=Serial_RxData;
			PIDPAG++;
			if(PIDPAG>=6)
			{
				RxState=0;
				PIDPAG=0;
			}
			return;
			
		}
		if(Serial_RxData==0x16)
		{
			RxState=1;
		}
		if(RxState==0)
		{
			P1=((Pid1[0]<<8)|Pid1[1]);
			I1=((Pid1[2]<<8)|Pid1[3]);
			D1=((Pid1[4]<<8)|Pid1[5]);
		}
		if(Serial_RxData==1)
		{
		    Serial_RxFlag=1;
		}
		if(Serial_RxData==2)
		{
			Serial_RxFlag=2;
		}
		if(Serial_RxData==0)
		{
			Serial_RxFlag=0;
		}
		if(Serial_RxData==3)
		{
			want=9000;
		}
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
	}
}
void Serial_SendPacked(void)
{
	Serial_OK=0;
	Serial_SendArray(Serial2_TxPacket,9);
	Serial_OK=1;
}



void send32bitInt(uint32_t data)
{
    uint8_t buffer[4];

    buffer[0] = (data >> 24) & 0xFF;
    buffer[1] = (data >> 16) & 0xFF;
    buffer[2] = (data >> 8) & 0xFF;
    buffer[3] = data & 0xFF;
	Serial_SendArray(buffer,4);
}

