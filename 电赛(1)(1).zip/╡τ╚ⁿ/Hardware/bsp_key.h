#ifndef BSP_KEY_H
#define BSP_KEY_H

#include <string.h>

#include "stdint.h"
#include "stm32f10x.h"
//#include "stm32f10x_gpio.h"
//#include "stm32f10x_pwr.h"
//#include "stm32f10x_bkp.h"

//#include "bsp.h"
//#include "bsp_common.h"
#include "delay.h"

#include "bsp_key.h"

//#include "bsp_icm20607.h"
//#include "IOI2C.h"

//#include "lcd.h"
//#include "lcd_init.h"

//#include "bsp_spi.h"
//#include "bsp_w25q64.h"

//#include "bsp_RGB.h"
//#include "bsp_usart.h"

#ifndef __BSP_H
#define __BSP_H

//#include "AllHeader.h"


void BSP_init(void);


#endif

//  ���Ŷ���
#define KEY1_GPIO_PORT GPIOB
#define KEY1_GPIO_PIN  GPIO_Pin_5
#define KEY1_GPIO_CLK  RCC_APB2Periph_GPIOB


// ����״̬����ʵ�ʵ�ƽ�෴��
#define KEY1_PRESS      1
#define KEY2_PRESS      2
#define KEY_RELEASE     0

#define KEY_MODE_ONE_TIME   1
#define KEY_MODE_ALWAYS     0


uint8_t Key_Scan(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);

void Key_GPIO_Init(void);
uint8_t Key1_State(uint8_t mode);
uint8_t Key1_Long_Press(uint16_t timeout);

//Test
uint8_t key_test(void);



#endif

