#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
uint16_t Encoder_Get(void);
extern int16_t rode;

#endif
