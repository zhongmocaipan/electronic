#include "stm32f10x.h"                  // Device header
extern int32_t want;
int16_t rode=0;
extern uint8_t Serial_RxFlag;

void Encoder_Init(void)
{
	//TIM5����ʱ��ʹ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
     
	GPIO_InitTypeDef GPIO_CSH1;
	GPIO_CSH1.GPIO_Mode=GPIO_Mode_IPU;//����������루�������룩
	GPIO_CSH1.GPIO_Pin=GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_CSH1.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_CSH1);
        	
	//�����������ڲ�ʱ��
	TIM_TimeBaseInitTypeDef TIM2_DINGYI;
	TIM2_DINGYI.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM2_DINGYI.TIM_CounterMode=TIM_CounterMode_Up;
	TIM2_DINGYI.TIM_Period=65535;//jsq
	TIM2_DINGYI.TIM_Prescaler=2;//yfpq
	TIM2_DINGYI.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TIM2_DINGYI);
	
	TIM_ICInitTypeDef TIM_ICInitStructure;
	TIM_ICStructInit(&TIM_ICInitStructure);//����ʼֵ
	
	TIM_ICInitStructure.TIM_Channel=TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICFilter=0xF;//�˲���
	TIM_ICInit(TIM2,&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel=TIM_Channel_2;
	TIM_ICInitStructure.TIM_ICFilter=0xF;//�˲���
	TIM_ICInit(TIM2,&TIM_ICInitStructure);
	
	TIM_EncoderInterfaceConfig(TIM2,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);//����ѡ��
	
	TIM_Cmd(TIM2,ENABLE);
}

uint16_t Encoder_Get(void)
{
	int16_t Temp;
	Temp = TIM_GetCounter(TIM2);
	if(Temp>30000||Temp<-30000)
	{
		if(Temp>30000)
		{
			rode++;
		}
		if(Temp<-30000)
		{
			rode--;
		}
		TIM_SetCounter(TIM2,0);
	}
	if(Temp>=1000&&Temp<=1100)
	{
		want+=9000;
	}
	if(Temp>2000)
	{
		Serial_RxFlag=0;
	}
	return Temp;
}

