#ifndef __USART2_H
#define	__USART2_H


extern uint8_t Serial2_TxPacket[10];

void MultiMachineControl(int16_t s1 , int16_t s2, int16_t s3,int16_t s4,int16_t s5,int16_t s6,int16_t time);

void MachineControl(int8_t id , int16_t angle, int16_t time);

void usart2_Init(u32 bound);


#endif
