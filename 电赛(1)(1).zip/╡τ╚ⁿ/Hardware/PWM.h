#ifndef __PWM_H
#define __PWM_H


void PWM_Init(void);
void PWM_SetZKB(uint16_t COM);
void PWM_SetZKBDJ(uint16_t COM);	
	
#endif
