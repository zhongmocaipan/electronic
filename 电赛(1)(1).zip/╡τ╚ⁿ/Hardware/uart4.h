#ifndef __UART4_H
#define	__UART4


extern uint8_t Serial4_TxPacket[10];
extern uint8_t Serial4_RxPacket[4];
extern uint8_t Serial4_RxFlag;
extern uint8_t Serial4_RxOK;

void usart4_Init(u32 bound);
uint8_t Serial4_GetRxFlag(void);

#endif
