#ifndef __PID_H
#define __PID_H

void Set_PID(int32_t P,int32_t I, int32_t D);
void PID_Init(void);
void PID (void);

extern int32_t PID_;

#endif
