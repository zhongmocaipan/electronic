#ifndef __DONG_H
#define __DONGI_H

void Zhuaqu(uint8_t qizi,uint8_t weizhi);

#endif
