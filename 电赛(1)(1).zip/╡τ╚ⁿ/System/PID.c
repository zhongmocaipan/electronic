#include "stm32f10x.h"                  // Device header
#include "usart2.h"
#include "Delay.h"

//��-��+
int32_t PIDContral[3]={1,0,0};
int32_t Angel_z[2]={0,0};
int32_t PID_Data[2]={0,0};//��ֵ
int32_t p_data;
int32_t i_data=0;
int32_t d_data;
uint8_t PID_Init_OK=0;
int32_t PID_;
int32_t want=0;
int32_t Cha=0;
int16_t z=0;

void Set_PID(int32_t P,int32_t I, int32_t D)
{
	PIDContral[0]=P;
	PIDContral[1]=I;
	PIDContral[2]=D;
}
void Update_PID_Data(void)
{
	Angel_z[1]=Angel_z[0];
	Angel_z[0]=z;
	PID_Data[1]=PID_Data[0];
	PID_Data[0]=Angel_z[0]-want;
}
void Update_pid_Data(void)
{
	p_data=PID_Data[0];
	i_data+=PID_Data[0];
	if(i_data>25000)
		i_data=25000;
	if(i_data<-25000)
		i_data=-25000;
	d_data=PID_Data[0]-PID_Data[1];
}

void PID_Init(void)
{
	i_data=0;
	Update_PID_Data();
	Delay_ms(10);
	Update_PID_Data();
	Update_pid_Data();
	PID_ = ((p_data-Cha)*PIDContral[0]+i_data/100*PIDContral[1]+d_data*PIDContral[2])/10000;
}

void PID (void)
{
	Update_PID_Data();
	Update_pid_Data();
	PID_ = ((p_data-Cha)*PIDContral[0]+i_data/100*PIDContral[1]+d_data*PIDContral[2])/10000;
}
