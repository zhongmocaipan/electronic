#ifndef __GPOI_H
#define __GPOI_H

void Gpio_Init(void);

#endif
