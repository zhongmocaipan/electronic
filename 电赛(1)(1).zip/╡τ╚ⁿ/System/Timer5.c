#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Serial.h"
#include "PID.h"
#include "PWM.h"
#include "Encoder.h"

extern uint16_t NUM;
extern uint8_t Serial_OK;
int32_t PID__;
extern uint8_t Serial_RxFlag;
int16_t coder;
extern int32_t want;
extern uint8_t Serial3_RxPacket[4];

void Timer_Init (void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
	TIM_InternalClockConfig(TIM4);//ʹ���ڲ�ʱ��
	TIM_TimeBaseInitTypeDef TIM4_DINGYI;
	TIM4_DINGYI.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM4_DINGYI.TIM_CounterMode=TIM_CounterMode_Up;
	TIM4_DINGYI.TIM_Period=100-1;//jsq
	TIM4_DINGYI.TIM_Prescaler=7200-1;//yfpq
	TIM4_DINGYI.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM4,&TIM4_DINGYI);
	
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_CSH;
	NVIC_CSH.NVIC_IRQChannel=TIM4_IRQn;
	NVIC_CSH.NVIC_IRQChannelCmd=ENABLE;
	NVIC_CSH.NVIC_IRQChannelPreemptionPriority=4;
	NVIC_CSH.NVIC_IRQChannelSubPriority=4;
	NVIC_Init(&NVIC_CSH);
	
	
	
}

void TIM4_IRQHandler(void)
{
	
    TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
}

uint16_t GETCOUNTER(TIM_TypeDef * TIMx)
{
	return TIM_GetCounter(TIMx);
}
