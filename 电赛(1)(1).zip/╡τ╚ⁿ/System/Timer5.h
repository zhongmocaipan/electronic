#ifndef __TIMER5_H
#define __TIMER5_H


void Timer_Init(void);
uint16_t GETCOUNTER(TIM_TypeDef * TIMx);


#endif
