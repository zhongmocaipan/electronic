#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "usart2.h"
#include "usart3.h"
#include "bsp_key.h"
#include "CountSonser.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

extern uint8_t qizi;
extern uint8_t weizhi;
extern uint8_t START;

void MultiMachineControl_1(void)
{
	MultiMachineControl(990,690,180,170,1010,1500,500);
	Delay_ms(1000);
	MultiMachineControl(990,690,180,170,1010,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_2(void)
{
	MultiMachineControl(880,780,70,210,860,1500,500);
	Delay_ms(1000);
	MultiMachineControl(880,780,70,210,860,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_3(void)
{
	MultiMachineControl(770,600,300,80,760,1500,500);
	Delay_ms(1000);
	MultiMachineControl(770,600,300,80,760,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_4(void)
{
	MultiMachineControl(1010,650,260,1,1200,1500,500);
	Delay_ms(1000);
	MultiMachineControl(1010,650,260,1,1200,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_5(void)
{
	MultiMachineControl(860,720,160,50,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(860,720,160,50,890,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_6(void)
{
	MultiMachineControl(750,800,80,110,750,1500,500);
	Delay_ms(1000);
	MultiMachineControl(750,800,80,110,750,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_7(void)
{
	MultiMachineControl(1040,810,80,1,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(1040,810,80,1,1070,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_8(void)
{
	MultiMachineControl(870,870,20,1,860,1500,500);
	Delay_ms(1000);
	MultiMachineControl(870,870,20,1,860,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
}
void MultiMachineControl_9(void)
{
	MultiMachineControl(700,860,1,50,720,1500,500);
	Delay_ms(1000);
	MultiMachineControl(700,860,1,50,720,800,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	
}

void white_1(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(1070,570,230,310,1070,500,500);
	Delay_ms(1000);
}

void white_2(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(1100,390,580,1,890,500,500);
	Delay_ms(1000);
}

void white_3(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(1150,670,150,190,1090,500,500);
	Delay_ms(1000);
}

void white_4(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(1190,660,180,80,890,500,500);
	Delay_ms(1000);
}

void white_5(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(1240,690,150,30,890,500,500);
	Delay_ms(1000);
}

void black_1(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(650,530,290,310,890,500,500);
	Delay_ms(1000);
}

void black_2(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(610,640,150,310,890,500,500);
	Delay_ms(1000);
}

void black_3(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(550,700,70,280,560,500,500);
	Delay_ms(1000);
}

void black_4(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(530,630,240,70,520,500,500);
	Delay_ms(1000);
}

void black_5(void)
{
	MultiMachineControl(900,1170,280,100,900,800,500);
	Delay_ms(1000);
	MultiMachineControl(460,620,240,20,500,500,500);
	Delay_ms(1000);
}




void whiteo1_to5(void)
{
	MultiMachineControl(900,1170,280,100,900,500,500);
	Delay_ms(1000);
	MultiMachineControl(1070,570,230,310,1070,500,500);
	Delay_ms(1000);
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl(870,840,20,130,880,1500,500);
	Delay_ms(1000);
	MultiMachineControl(870,840,20,130,880,500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,500,500);
	Delay_ms(1000);
}

void whiteo1_to1(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void whiteo1_to2(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void whiteo1_to3(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void whiteo1_to4(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void whiteo1_to6(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void whiteo1_to7(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void whiteo1_to8(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void whiteo1_to9(void)
{
	white_1();
	MultiMachineControl(1070,570,230,310,1070,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void whiteo2_to1(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void whiteo2_to2(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void whiteo2_to3(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void whiteo2_to4(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void whiteo2_to5(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void whiteo2_to6(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void whiteo2_to7(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void whiteo2_to8(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void whiteo2_to9(void)
{
	white_2();
	MultiMachineControl(1100,390,580,1,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void whiteo3_to1(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void whiteo3_to2(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void whiteo3_to3(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void whiteo3_to4(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void whiteo3_to5(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void whiteo3_to6(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void whiteo3_to7(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void whiteo3_to8(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void whiteo3_to9(void)
{
	white_3();
	MultiMachineControl(1150,670,150,190,1090,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void whiteo4_to1(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void whiteo4_to2(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void whiteo4_to3(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void whiteo4_to4(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void whiteo4_to5(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void whiteo4_to6(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void whiteo4_to7(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void whiteo4_to8(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void whiteo4_to9(void)
{
	white_4();
	MultiMachineControl(1190,660,180,80,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void whiteo5_to1(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void whiteo5_to2(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void whiteo5_to3(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void whiteo5_to4(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void whiteo5_to5(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void whiteo5_to6(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void whiteo5_to7(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void whiteo5_to8(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void whiteo5_to9(void)
{
	white_5();
	MultiMachineControl(1240,690,150,30,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}


void black1_to1(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void black1_to2(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void black1_to3(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void black1_to4(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void black1_to5(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void black1_to6(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void black1_to7(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void black1_to8(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}
void black1_to9(void)
{
	black_1();
	MultiMachineControl(650,530,290,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void black2_to1(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void black2_to2(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void black2_to3(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void black2_to4(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void black2_to5(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void black2_to6(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void black2_to7(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void black2_to8(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void black2_to9(void)
{
	black_2();
	MultiMachineControl(610,640,150,310,890,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void black3_to1(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void black3_to2(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void black3_to3(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void black3_to4(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void black3_to5(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void black3_to6(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void black3_to7(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void black3_to8(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void black3_to9(void)
{
	black_3();
	MultiMachineControl(550,700,70,280,560,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void black4_to1(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void black4_to2(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void black4_to3(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void black4_to4(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void black4_to5(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void black4_to6(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void black4_to7(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void black4_to8(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void black4_to9(void)
{
	black_4();
	MultiMachineControl(530,630,240,70,520,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void black5_to1(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_1();
	
}

void black5_to2(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_2();
	
}

void black5_to3(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_3();
	
}

void black5_to4(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_4();
	
}

void black5_to5(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_5();
	
}

void black5_to6(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_6();
	
}

void black5_to7(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_7();
	
}

void black5_to8(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_8();
	
}

void black5_to9(void)
{
	black_5();
	MultiMachineControl(460,620,240,20,500,1500,500);
	Delay_ms(1000);
	MultiMachineControl(900,1170,280,100,900,1500,500);
	Delay_ms(1000);
	MultiMachineControl_9();
	
}

void Zhuaqu(uint8_t qizi,uint8_t weizhi)
{
	if(qizi==1&&weizhi==1)
	{
		whiteo1_to1();
	}
	if(qizi==1&&weizhi==2)
	{
		whiteo1_to2();
	}
	if(qizi==1&&weizhi==3)
	{
		whiteo1_to3();
	}
	if(qizi==1&&weizhi==4)
	{
		whiteo1_to4();
	}
	if(qizi==1&&weizhi==5)
	{
		whiteo1_to5();
	}
	if(qizi==1&&weizhi==6)
	{
		whiteo1_to6();
	}
	if(qizi==1&&weizhi==7)
	{
		whiteo1_to7();
	}
	if(qizi==1&&weizhi==8)
	{
		whiteo1_to8();
	}
	if(qizi==1&&weizhi==9)
	{
		whiteo1_to9();
	}
	if(qizi==2&&weizhi==1)
	{
		whiteo2_to1();
	}
	if(qizi==2&&weizhi==2)
	{
		whiteo2_to2();
	}
	if(qizi==2&&weizhi==3)
	{
		whiteo2_to3();
	}
	if(qizi==2&&weizhi==4)
	{
		whiteo2_to4();
	}
	if(qizi==2&&weizhi==5)
	{
		whiteo2_to5();
	}
	if(qizi==2&&weizhi==6)
	{
		whiteo2_to6();
	}
	if(qizi==2&&weizhi==7)
	{
		whiteo2_to7();
	}
	if(qizi==2&&weizhi==8)
	{
		whiteo2_to8();
	}
	if(qizi==2&&weizhi==9)
	{
		whiteo2_to1();
	}
	if(qizi==3&&weizhi==1)
	{
		whiteo3_to1();
	}
	if(qizi==3&&weizhi==2)
	{
		whiteo3_to2();
	}
	if(qizi==3&&weizhi==3)
	{
		whiteo3_to3();
	}
	if(qizi==3&&weizhi==4)
	{
		whiteo3_to4();
	}
	if(qizi==3&&weizhi==5)
	{
		whiteo3_to5();
	}
	if(qizi==3&&weizhi==6)
	{
		whiteo3_to6();
	}
	if(qizi==3&&weizhi==7)
	{
		whiteo3_to7();
	}
	if(qizi==3&&weizhi==8)
	{
		whiteo3_to8();
	}
	if(qizi==3&&weizhi==9)
	{
		whiteo3_to9();
	}
	if(qizi==4&&weizhi==1)
	{
		whiteo4_to1();
	}
	if(qizi==4&&weizhi==2)
	{
		whiteo4_to2();
	}
	if(qizi==4&&weizhi==3)
	{
		whiteo4_to3();
	}
	if(qizi==4&&weizhi==4)
	{
		whiteo4_to4();
	}
	if(qizi==4&&weizhi==5)
	{
		whiteo4_to5();
	}
	if(qizi==4&&weizhi==6)
	{
		whiteo4_to6();
	}
	if(qizi==4&&weizhi==7)
	{
		whiteo4_to7();
	}
	if(qizi==4&&weizhi==8)
	{
		whiteo4_to8();
	}
	if(qizi==4&&weizhi==9)
	{
		whiteo4_to9();
	}
	if(qizi==5&&weizhi==1)
	{
		whiteo5_to1();
	}
	if(qizi==5&&weizhi==2)
	{
		whiteo5_to2();
	}
	if(qizi==5&&weizhi==3)
	{
		whiteo5_to3();
	}
	if(qizi==5&&weizhi==4)
	{
		whiteo5_to4();
	}
	if(qizi==5&&weizhi==5)
	{
		whiteo5_to5();
	}
	if(qizi==5&&weizhi==6)
	{
		whiteo5_to6();
	}
	if(qizi==5&&weizhi==7)
	{
		whiteo5_to7();
	}
	if(qizi==5&&weizhi==8)
	{
		whiteo5_to8();
	}
	if(qizi==5&&weizhi==9)
	{
		whiteo5_to9();
	}
	if(qizi==6&&weizhi==1)
	{
		black1_to1();
	}
	if(qizi==6&&weizhi==2)
	{
		black1_to2();
	}
	if(qizi==6&&weizhi==3)
	{
		black1_to3();
	}
	if(qizi==6&&weizhi==4)
	{
		black1_to4();
	}
	if(qizi==6&&weizhi==5)
	{
		black1_to5();
	}
	if(qizi==6&&weizhi==6)
	{
		black1_to6();
	}
	if(qizi==6&&weizhi==7)
	{
		black1_to7();
	}
	if(qizi==6&&weizhi==8)
	{
		black1_to8();
	}
	if(qizi==6&&weizhi==9)
	{
		black1_to9();
	}
	if(qizi==7&&weizhi==1)
	{
		black2_to1();
	}
	if(qizi==7&&weizhi==2)
	{
		black2_to2();
	}
	if(qizi==7&&weizhi==3)
	{
		black2_to3();
	}
	if(qizi==7&&weizhi==4)
	{
		black2_to4();
	}
	if(qizi==7&&weizhi==5)
	{
		black2_to5();
	}
	if(qizi==7&&weizhi==6)
	{
		black2_to6();
	}
	if(qizi==7&&weizhi==7)
	{
		black2_to7();
	}
	if(qizi==7&&weizhi==8)
	{
		black2_to8();
	}
	if(qizi==7&&weizhi==9)
	{
		black2_to9();
	}
	if(qizi==8&&weizhi==1)
	{
		black3_to1();
	}
	if(qizi==8&&weizhi==2)
	{
		black3_to2();
	}
	if(qizi==8&&weizhi==3)
	{
		black3_to3();
	}
	if(qizi==8&&weizhi==4)
	{
		black3_to4();
	}
	if(qizi==8&&weizhi==5)
	{
		black3_to5();
	}
	if(qizi==8&&weizhi==6)
	{
		black3_to6();
	}
	if(qizi==8&&weizhi==7)
	{
		black3_to7();
	}
	if(qizi==8&&weizhi==8)
	{
		black3_to8();
	}
	if(qizi==8&&weizhi==9)
	{
		black3_to9();
	}
	if(qizi==9&&weizhi==1)
	{
		black4_to1();
	}
	if(qizi==9&&weizhi==2)
	{
		black4_to2();
	}
	if(qizi==9&&weizhi==3)
	{
		black4_to3();
	}
	if(qizi==9&&weizhi==4)
	{
		black4_to4();
	}
	if(qizi==9&&weizhi==5)
	{
		black4_to5();
	}
	if(qizi==9&&weizhi==6)
	{
		black4_to6();
	}
	if(qizi==9&&weizhi==7)
	{
		black4_to7();
	}
	if(qizi==9&&weizhi==8)
	{
		black4_to8();
	}
	if(qizi==9&&weizhi==9)
	{
		black4_to9();
	}
	if(qizi==10&&weizhi==1)
	{
		black5_to1();
	}
	if(qizi==10&&weizhi==2)
	{
		black5_to2();
	}
	if(qizi==10&&weizhi==3)
	{
		black5_to3();
	}
	if(qizi==10&&weizhi==4)
	{
		black5_to4();
	}
	if(qizi==10&&weizhi==5)
	{
		black5_to5();
	}
	if(qizi==10&&weizhi==6)
	{
		black5_to6();
	}
	if(qizi==10&&weizhi==7)
	{
		black5_to7();
	}
	if(qizi==10&&weizhi==8)
	{
		black5_to8();
	}
	if(qizi==10&&weizhi==9)
	{
		black5_to9();
	}
	
}
