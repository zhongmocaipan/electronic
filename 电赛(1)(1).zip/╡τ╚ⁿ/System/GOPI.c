
#include "stm32f10x.h"                  // Device header

void Gpio_Init(void)
{
	

}
