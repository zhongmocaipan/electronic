#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "usart2.h"
#include "usart3.h"
#include "bsp_key.h"
#include "CountSonser.h"
#include "dong.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>


extern uint8_t qizi;
extern uint8_t weizhi;
extern uint8_t START;



int main(void)
{
	uint8_t Key;
	Key_GPIO_Init();
	CountSensor_Init();
	usart2_Init(115200);
	OLED_Init();
	Delay_ms(20);
	MultiMachineControl(900,900,1,1,900,800,500);
	OLED_ShowString(25,16,"qizi",OLED_8X16);
	OLED_ShowString(17,32,"weizhi",OLED_8X16);
	while (1)
	{
		OLED_ShowNum(0,16,qizi,2,OLED_8X16);
		OLED_ShowNum(0,32,weizhi,1,OLED_8X16);
		OLED_Update();
		
		Key=Key1_State(1);
		if(START)
		{
			OLED_ShowNum(0,48,START,1,OLED_8X16);
		    OLED_ShowString(17,48,"START",OLED_8X16);
		    OLED_Update();
			Zhuaqu(qizi,weizhi);
			Delay_ms(5);
			MultiMachineControl(900,900,1,1,900,800,500);
			START=0;
		}
		OLED_ShowNum(0,48,START,1,OLED_8X16);
		OLED_ShowString(17,48,"START",OLED_8X16);
		OLED_Update();
	}
}
